#include "Emoji.h"

/*
 * Implement your emojis in this file.
 **/

// A yellow, empty face.
Face::Face(Point c, int r)
{
	/* TODO:
	 *  - add member initializer list
	 *  - implement the constructor. I.e. fill color
	 **/

	cout << "Not yet implemented\n";
}

void Face::attach_to(Graph_lib::Window& win)
{
	/* TODO:
	 *  - attach shapes to window
	 **/
}

/* TODO:
 *  - define more emojis.
 **/
